export enum ProfitPeriod {
  ALL_TIME = 'all_time',
  TODAY = 'today',
  WEEK = 'week',
  MONTH = 'month',
  YEAR = 'year',
}
